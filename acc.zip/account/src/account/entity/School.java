/**
 * @author 程森
 *2017年10月13日下午11:14:53
 */
package account.entity;

/**
 * @author 程森
 *2017年10月13日下午11:14:53
 */
public class School {
   private String id;
   private String name;
   private  String jibie;
public  String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getJibie() {
	return jibie;
}
public void setJibie(String jibie) {
	this.jibie = jibie;
}
   
}
