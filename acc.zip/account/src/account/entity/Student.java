/**
 * @author 程森
 *2017年10月14日上午9:48:31
 */
package account.entity;

/**
 * @author 程森
 *2017年10月14日上午9:48:31
 */
public class Student {
   private String id;
   private String name;
   private String teacher;
   private String schoolid;
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getTeacher() {
	return teacher;
}
public void setTeacher(String teacher) {
	this.teacher = teacher;
}
public String getSchoolid() {
	return schoolid;
}
public void setSchoolid(String schoolid) {
	this.schoolid = schoolid;
}
   
}
